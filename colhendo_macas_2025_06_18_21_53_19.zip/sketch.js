// --- Variáveis Globais ---
let macas = [];
let pontuacao = 0;
let arvores = [];
let personagem;
let velocidade = 3;

// Ferramenta (vara de colheita vista de cima)
let ferramenta = {
  comprimento: 40,
  angulo: 0,
  emUso: false, // Indica se a ferramenta está ativa para colheita
  origemX: 0,
  origemY: 0
};

// Variável para controlar o modo de seguir o mouse da ferramenta
let modoFerramentaMouse = false;

// Raios de colisão para o personagem e as árvores
const PERSONAGEM_RAIO_COLISAO = 15;
const ARVORE_RAIO_COLISAO = 40;

// --- Variáveis do Timer ---
let tempoTotalJogo = 45; // Tempo total do jogo em segundos (45 segundos)
let tempoRestante = tempoTotalJogo; // Tempo restante atual
let jogoAcabou = false; // Flag para indicar se o jogo terminou
let timerIniciado = false; // Flag para controlar se o timer já foi iniciado

// --- Pré-carregamento de Imagens (se for usar sprites no futuro) ---
function preload() {
  // Exemplo: applePixelArt = loadImage('assets/apple_pixel.png');
}

// --- Configuração Inicial ---
function setup() {
  createCanvas(680, 475); // Define o tamanho do canvas do jogo
  noSmooth(); // Desativa o anti-aliasing para um visual mais pixelado (estilo "pixel art")

  // Inicialização do objeto do personagem agricultor
  personagem = {
    x: width / 2, // Posição X inicial no centro da tela
    y: height / 2, // Posição Y inicial no centro da tela
    largura: 30,
    altura: 40,
    direcao: 0 // Direção inicial do personagem: 0 (baixo), 1 (direita), 2 (cima), 3 (esquerda)
  };

  // Cria as árvores sem sobreposição
  let numArvores = 5;
  let minDistanciaArvores = 150; // Distância mínima entre o centro das árvores para evitar sobreposição

  for (let i = 0; i < numArvores; i++) {
    let novaArvore;
    let tentando = true;
    let attempts = 0;
    // Tenta criar uma nova árvore até que ela não se sobreponha a outras já existentes
    while (tentando && attempts < 100) { // Limita as tentativas para evitar loops infinitos
      novaArvore = {
        x: random(100, width - 100), // Posição X aleatória dentro de limites para não ficar na borda
        y: random(150, height - 150) // Posição Y aleatória, evitando a parte superior da tela e a faixa de "terra" inferior
      };
      let sobreposicao = false;
      for (let arvoreExistente of arvores) {
        let distancia = dist(novaArvore.x, novaArvore.y, arvoreExistente.x, arvoreExistente.y);
        if (distancia < minDistanciaArvores) {
          sobreposicao = true; // Há sobreposição, precisa tentar novamente
          break;
        }
      }
      if (!sobreposicao) {
        arvores.push(novaArvore); // Se não houver sobreposição, adiciona a nova árvore
        tentando = false; // Sai do loop de tentativa
      }
      attempts++;
    }
  }

  criarMacasNasArvores(); // Popula as árvores com maçãs iniciais logo após a criação das árvores
}

// --- Criação de Maçãs ---
function criarMacasNasArvores() {
  macas = []; // Limpa todas as maçãs existentes antes de criar novas
  for (let arvore of arvores) {
    let qtdMacas = floor(random(3, 6)); // Define uma quantidade aleatória de maçãs por árvore (entre 3 e 5)
    for (let i = 0; i < qtdMacas; i++) {
      macas.push({
        x: arvore.x + random(-30, 30), // Posição X aleatória ligeiramente deslocada do centro da árvore
        y: arvore.y + random(-30, 30) - 30, // Posição Y aleatória ligeiramente deslocada e ajustada para a altura da copa
        coletada: false, // Estado inicial: maçã não coletada
        arvoreId: arvores.indexOf(arvore), // Guarda o índice da árvore à qual esta maçã pertence
        tamanho: 15
      });
    }
  }
}

// --- Função do Timer ---
function contarTempo() {
  if (!jogoAcabou) { // Só decrementa se o jogo não tiver acabado
    tempoRestante--;
    if (tempoRestante <= 0) {
      tempoRestante = 0; // Garante que não fique negativo
      jogoAcabou = true; // Define a flag para indicar que o jogo terminou
    }
  }
}

// --- Loop Principal do Jogo ---
function draw() {
  background(135, 206, 235); // Desenha o céu com uma cor azul clara

  desenharChaoFazenda(); // Desenha o chão antes de tudo

  // Ordena as árvores com base na sua posição Y.
  // Isso garante que as árvores mais abaixo no cenário sejam desenhadas por último,
  // criando um efeito de profundidade onde o personagem pode passar por trás delas.
  arvores.sort((a, b) => a.y - b.y);
  for (let arvore of arvores) {
    desenharArvore(arvore.x, arvore.y);
  }

  // --- Movimento do Agricultor ---
  let moveX = 0;
  let moveY = 0;

  // O movimento e a lógica de colheita só funcionam se o jogo não tiver acabado
  if (!jogoAcabou) {
    // Verifica as teclas de seta pressionadas para determinar o movimento
    if (keyIsDown(LEFT_ARROW)) {
      moveX = -velocidade;
      personagem.direcao = 3; // Esquerda
    }
    if (keyIsDown(RIGHT_ARROW)) {
      moveX = velocidade;
      personagem.direcao = 1; // Direita
    }
    if (keyIsDown(UP_ARROW)) {
      moveY = -velocidade;
      personagem.direcao = 2; // Cima (costas)
    }
    if (keyIsDown(DOWN_ARROW)) {
      moveY = velocidade;
      personagem.direcao = 0; // Baixo (frente)
    }

    // NOVA LÓGICA: Inicia o timer na primeira vez que o personagem se move
    if (!timerIniciado && (moveX !== 0 || moveY !== 0)) {
      timerIniciado = true;
      setInterval(contarTempo, 1000); // Inicia o timer
    }

    // Calcula a próxima posição potencial do personagem
    let nextX = personagem.x + moveX;
    let nextY = personagem.y + moveY;

    // Aplica o movimento no eixo X e verifica colisão com árvores.
    // Se houver colisão, o movimento é revertido para o eixo X.
    personagem.x = nextX;
    if (checkTreeCollision()) {
      personagem.x = nextX - moveX; // Reverte o movimento no X
    }

    // Aplica o movimento no eixo Y e verifica colisão com árvores.
    // Se houver colisão, o movimento é revertido para o eixo Y.
    personagem.y = nextY;
    if (checkTreeCollision()) {
      personagem.y = nextY - moveY; // Reverte o movimento no Y
    }

    // Restringe o personagem aos limites visíveis da tela e à área de jogo.
    // Isso impede que o personagem saia da tela ou entre na área "superior" (céu puro).
    personagem.x = constrain(personagem.x, PERSONAGEM_RAIO_COLISAO, width - PERSONAGEM_RAIO_COLISAO);
    personagem.y = constrain(personagem.y, 80 + PERSONAGEM_RAIO_COLISAO, height - PERSONAGEM_RAIO_COLISAO);


    // --- Atualização da Ferramenta ---
    // Define o ponto de origem da ferramenta (a "mão" do personagem)
    ferramenta.origemX = personagem.x;
    ferramenta.origemY = personagem.y + personagem.altura * 0.2; // Ajuste para a altura da mão

    // Comportamento da ferramenta baseado em 'modoFerramentaMouse'
    if (modoFerramentaMouse) {
      ferramenta.emUso = true; // A ferramenta está ativa e pode coletar
      // O ângulo da ferramenta é calculado para apontar do personagem para o ponteiro do mouse
      ferramenta.angulo = atan2(mouseY - ferramenta.origemY, mouseX - ferramenta.origemX);
    } else {
      ferramenta.emUso = false; // A ferramenta não está ativa para coleta
      // Quando não está em uso, a ferramenta aponta na mesma direção do personagem
      if (personagem.direcao === 0) { // Baixo (frente)
        ferramenta.angulo = PI / 2;
      } else if (personagem.direcao === 1) { // Direita
        ferramenta.angulo = 0;
      } else if (personagem.direcao === 2) { // Cima (costas)
        ferramenta.angulo = -PI / 2;
      } else if (personagem.direcao === 3) { // Esquerda
        ferramenta.angulo = PI;
      }
    }

    // --- Lógica das Maçãs ---
    // Itera sobre as maçãs de trás para frente (importante para remover elementos de um array enquanto itera)
    for (let i = macas.length - 1; i >= 0; i--) {
      let maca = macas[i];
      if (!maca.coletada) { // Só desenha e verifica maçãs que ainda não foram coletadas
        desenharMaca(maca.x, maca.y, maca.tamanho);

        // --- Verificação de Colisão da Ferramenta com Maçã ---
        // A colisão para coleta só ocorre se o modoFerramentaMouse estiver ativo
        if (modoFerramentaMouse) {
          // Calcula a posição exata da ponta da ferramenta
          let pontaFerramentaX = ferramenta.origemX + cos(ferramenta.angulo) * ferramenta.comprimento;
          let pontaFerramentaY = ferramenta.origemY + sin(ferramenta.angulo) * ferramenta.comprimento;

          // Verifica a distância entre a maçã e a ponta da ferramenta.
          // Se estiverem próximos o suficiente (colisão), a maçã é coletada.
          if (dist(maca.x, maca.y, pontaFerramentaX, pontaFerramentaY) < (maca.tamanho / 2) + 5) {
            maca.coletada = true; // Marca a maçã como coletada
            pontuacao++; // Incrementa a pontuação do jogador

            // Se todas as maçãs da árvore original desta maçã foram coletadas.
            // Se sim, recria as maçãs para aquela árvore.
            if (todasMacasColetadas(maca.arvoreId)) {
              recriarMacasParaArvore(maca.arvoreId);
            }
          }
        }
      }
    }
  } // Fim do if (!jogoAcabou)

  desenharAgricultor(); // Desenha o agricultor
  desenharFerramenta(); // Desenha a ferramenta (desenhada por último para aparecer por cima do agricultor)

  // --- Exibição de Pontuação e Instruções (Fixas na tela) ---
  fill(0); // Define a cor do texto para preto
  textSize(24); // Define o tamanho da fonte
  textAlign(LEFT, TOP); // Garante alinhamento padrão para este texto
  text("Maçãs: " + pontuacao, 20, 30); // Exibe a pontuação no canto superior esquerdo

  // --- Exibição do Timer Regressivo ---
  fill(0); // Cor do texto
  textSize(24);
  textAlign(RIGHT, TOP); // Alinha o texto à direita e ao topo
  text("Tempo: " + formatarTempo(tempoRestante), width - 20, 30); // Exibe o tempo no canto superior direito

  textSize(16); // Define o tamanho da fonte para as instruções
  textAlign(LEFT, BOTTOM); // Alinha o texto à esquerda e na parte inferior
  let instrucoes = "Setas: Mover | ENTER: Ativar/Desativar Ferramenta | Mouse: Apontar";
  // Adiciona o estado atual da ferramenta às instruções
  if (modoFerramentaMouse) {
    instrucoes += " (ATIVADO)";
  } else {
    instrucoes += " (DESATIVADO)";
  }
  // Se o timer ainda não foi iniciado, adiciona uma instrução extra
  if (!timerIniciado) {
    instrucoes += " | Mova-se para iniciar o tempo!";
  }
  text(instrucoes, 20, height - 20); // Exibe as instruções no canto inferior esquerdo


  // --- Tela de Fim de Jogo ---
  if (jogoAcabou) {
    fill(0, 0, 0, 200); // Fundo semi-transparente escuro
    rect(0, 0, width, height); // Cobre a tela

    fill(255); // Texto branco
    textAlign(CENTER, CENTER); // Centraliza o texto
    textSize(48);
    text("FIM DE JOGO!", width / 2, height / 2 - 50);
    textSize(32);
    text("Maçãs Coletadas: " + pontuacao, width / 2, height / 2 + 10);
    textSize(20);
    text("Pressione F5 para jogar novamente", width / 2, height / 2 + 70);
  }
}

// --- Funções de Interação ---
// Esta função é chamada automaticamente pelo p5.js quando uma tecla é solta
function keyReleased() {
  if (!jogoAcabou && keyCode === ENTER) { // Só alterna se o jogo não tiver acabado
    modoFerramentaMouse = !modoFerramentaMouse; // Inverte o estado da variável para alternar o modo da ferramenta
  }
}

// --- Funções de Desenho ---
function desenharChaoFazenda() {
  // Desenha o "chão" de grama usando retângulos grandes que cobrem a tela
  fill(100, 200, 100); // Cor verde para a grama
  noStroke(); // Remove o contorno
  for (let y = 0; y < height; y += 40) {
    for (let x = 0; x < width; x += 40) {
      rect(x, y, 40, 40); // Desenha múltiplos retângulos para formar o chão
    }
  }
  // Desenha uma faixa de "terra" na parte inferior da tela, como um caminho ou canteiro
  fill(170, 110, 70); // Cor marrom para a terra
  rect(0, height - 80, width, 80); // Um retângulo que ocupa a largura total na parte inferior
}

function desenharFerramenta() {
  push(); // Salva o estado atual da transformação (posição, rotação, etc.)
  translate(ferramenta.origemX, ferramenta.origemY); // Move a origem do desenho para a "mão" do personagem
  rotate(ferramenta.angulo); // Rotaciona tudo que será desenhado a partir desta origem pelo ângulo da ferramenta

  // Desenha o cabo da ferramenta (uma vara simples)
  stroke(200, 100, 70); // Cor marrom clara para o cabo
  strokeWeight(3); // Espessura da linha do cabo
  line(0, 0, ferramenta.comprimento, 0); // Desenha a linha horizontalmente; a rotação no 'rotate()' a posiciona corretamente

  // Desenha a parte de coleta (um pequeno círculo na ponta da vara)
  noStroke(); // Remove o contorno para o círculo
  fill(200); // Cor cinza clara para a ponta
  ellipse(ferramenta.comprimento, 0, 15, 15); // Círculo na extremidade do comprimento da ferramenta

  pop(); // Restaura o estado da transformação salvo anteriormente, para não afetar outros desenhos
}

function desenharAgricultor() {
  push(); // Salva o estado atual da transformação
  translate(personagem.x, personagem.y); // Move a origem do desenho para a posição do agricultor

  // Corpo do agricultor (visto de cima, desenhado como uma elipse)
  fill(10, 199, 167); // Cor da roupa (azul esverdeado)
  ellipse(0, 0, personagem.largura, personagem.altura * 0.8); // Formato oval para o corpo

  // Cabeça do agricultor
  fill(230, 205, 148); // Cor da pele
  ellipse(0, -personagem.altura * 0.4, personagem.largura * 0.8, personagem.altura * 0.6); // Elipse para a cabeça, posicionada acima do corpo

  // Chapéu (vista de cima, com aba e topo)
  fill(210, 180, 140); // Cor do chapéu
  ellipse(0, -personagem.altura * 0.55, personagem.largura * 1.2, personagem.largura * 0.9); // Aba maior do chapéu
  ellipse(0, -personagem.altura * 0.55, personagem.largura * 0.7, personagem.largura * 0.6); // Topo menor do chapéu

  // Olhos (desenhados apenas se o personagem estiver de frente, direita ou esquerda)
  fill(0); // Cor preta para os olhos
  if (personagem.direcao === 0) { // Frente
    ellipse(-5, -personagem.altura * 0.45, 3, 3);
    ellipse(5, -personagem.altura * 0.45, 3, 3);
  } else if (personagem.direcao === 1) { // Direita
    ellipse(7, -personagem.altura * 0.45, 3, 3);
  } else if (personagem.direcao === 2) { // Costas (sem olhos, pois não são visíveis)
    // Não desenha olhos
  } else if (personagem.direcao === 3) { // Esquerda
    ellipse(-7, -personagem.altura * 0.45, 3, 3);
  }

  // Braços (círculos simples ao lado do corpo)
  fill(255, 205, 148); // Cor da pele
  ellipse(personagem.largura * 0.4, 0, 8, 8); // Braço direito
  ellipse(-personagem.largura * 0.4, 0, 8, 8); // Braço esquerdo

  pop(); // Restaura o estado da transformação
}

function desenharArvore(x, y) {
  // Tronco da árvore (desenhado como um quadrilátero)
  fill(139, 69, 19); // Cor marrom para o tronco
  quad(
    x - 15, y, // Canto inferior esquerdo
    x + 15, y, // Canto inferior direito
    x + 10, y - 50, // Canto superior direito
    x - 10, y - 50 // Canto superior esquerdo
  );

  // Folhagem principal da árvore (desenhada como uma elipse grande)
  fill(0, 100, 0); // Verde escuro para a folhagem
  ellipse(x, y - 50, 100, 100); // Elipse centrada acima do tronco

  // Detalhes da folhagem (bolinhas menores para dar mais textura e profundidade)
  fill(0, 120, 0, 150); // Verde um pouco mais claro e semi-transparente
  ellipse(x + 30, y - 60, 20, 20); // Bolinha de detalhe 1
  ellipse(x - 25, y - 40, 20, 20); // Bolinha de detalhe 2
}

function desenharMaca(x, y, tamanho) {
  fill(255, 0, 0); // Cor vermelha para a maçã
  ellipse(x, y, tamanho, tamanho); // Corpo da maçã (círculo)
  fill(0, 128, 0); // Cor verde para o talo
  rect(x - 1, y - tamanho / 2 - 3, 2, 5); // Talo da maçã (pequeno retângulo acima)
}

// --- Funções de Lógica do Jogo ---
// Verifica se o personagem está colidindo com alguma árvore
function checkTreeCollision() {
  let pX = personagem.x;
  let pY = personagem.y;
  let pRadius = PERSONAGEM_RAIO_COLISAO; // Raio de colisão do personagem

  for (let arvore of arvores) {
    // Ajusta a posição Y da árvore para o ponto de colisão mais relevante (base da folhagem/topo do tronco)
    let aX = arvore.x;
    let aY = arvore.y - 30;

    let aRadius = ARVORE_RAIO_COLISAO; // Raio de colisão da árvore

    let d = dist(pX, pY, aX, aY); // Calcula a distância entre o centro do personagem e o ponto de colisão da árvore

    if (d < pRadius + aRadius) {
      return true; // Há colisão se a distância for menor que a soma dos raios
    }
  }
  return false; // Nenhuma colisão detectada
}

// Verifica se todas as maçãs de uma árvore específica foram coletadas
function todasMacasColetadas(arvoreId) {
  for (let maca of macas) {
    // Se encontrar uma maçã pertencente àquela árvore (arvoreId) que ainda não foi coletada, retorna falso
    if (maca.arvoreId === arvoreId && !maca.coletada) {
      return false;
    }
  }
  return true; // Se o loop terminar e nenhuma maçã não coletada for encontrada, significa que todas foram coletadas
}

// Recria as maçãs para uma árvore específica, geralmente após todas as suas maçãs terem sido coletadas
function recriarMacasParaArvore(arvoreId) {
  let arvore = arvores[arvoreId]; // Obtém o objeto da árvore usando seu ID
  let qtdMacas = floor(random(3, 6)); // Define uma nova quantidade aleatória de maçãs para esta árvore

  // Filtra o array `macas`, removendo todas as maçãs que pertencem a esta árvore E já foram coletadas.
  // Isso mantém as maçãs não coletadas de outras árvores.
  macas = macas.filter(m => !(m.arvoreId === arvoreId && m.coletada));

  // Adiciona novas maçãs para a árvore selecionada
  for (let i = 0; i < qtdMacas; i++) {
    macas.push({
      x: arvore.x + random(-30, 30), // Posição X aleatória ao redor da árvore
      y: arvore.y + random(-30, 30) - 30, // Posição Y aleatória ao redor da árvore (ajustada para cima)
      coletada: false, // As novas maçãs começam como não coletadas
      arvoreId: arvoreId, // Mantém a associação com a árvore original
      tamanho: 15
    });
  }
}

// --- Funções de Formatação ---
// Formata o tempo de segundos para "MM:SS"
function formatarTempo(segundos) {
  let minutos = floor(segundos / 60);
  let segs = segundos % 60;
  // Adiciona um zero à esquerda se os segundos ou minutos forem menores que 10
  return nf(minutos, 2) + ':' + nf(segs, 2);
}